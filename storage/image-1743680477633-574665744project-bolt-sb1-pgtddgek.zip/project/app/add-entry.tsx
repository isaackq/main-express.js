import { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  useColorScheme,
  Platform,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import * as SQLite from 'expo-sqlite';
import { ArrowLeft } from 'lucide-react-native';

export default function AddEntryScreen() {
  const { day } = useLocalSearchParams<{ day: string }>();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  const [formData, setFormData] = useState({
    memorizationSurah: '',
    memorizationFrom: '',
    memorizationTo: '',
    revisionSurah: '',
    revisionFrom: '',
    revisionTo: '',
  });

  const handleSave = () => {
    if (Platform.OS === 'ios' || Platform.OS === 'android') {
      try {
        const db = SQLite.openDatabase('qurantrack.db');
        
        db.transaction(tx => {
          tx.executeSql(
            `INSERT INTO schedule (
              day,
              memorizationSurah,
              memorizationFrom,
              memorizationTo,
              revisionSurah,
              revisionFrom,
              revisionTo,
              status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              day,
              formData.memorizationSurah,
              parseInt(formData.memorizationFrom),
              parseInt(formData.memorizationTo),
              formData.revisionSurah,
              parseInt(formData.revisionFrom),
              parseInt(formData.revisionTo),
              'Not Completed'
            ],
            () => {
              router.back();
            },
            (_, error) => {
              console.error('Error saving entry:', error);
              return false;
            }
          );
        });
      } catch (error) {
        console.error('Error opening database:', error);
        router.back();
      }
    } else {
      router.back();
    }
  };

  return (
    <View style={[
      styles.container,
      { backgroundColor: isDark ? '#121212' : '#F5F5F5' }
    ]}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
        >
          <ArrowLeft
            size={24}
            color={isDark ? '#FFFFFF' : '#000000'}
          />
        </TouchableOpacity>
        <Text style={[
          styles.title,
          { color: isDark ? '#FFFFFF' : '#000000' }
        ]}>
          Add Entry for {day}
        </Text>
      </View>

      <ScrollView style={styles.form}>
        <View style={styles.section}>
          <Text style={[
            styles.sectionTitle,
            { color: isDark ? '#4CAF50' : '#2E7D32' }
          ]}>
            Memorization
          </Text>
          <TextInput
            style={[
              styles.input,
              { 
                backgroundColor: isDark ? '#1A1B1E' : '#FFFFFF',
                color: isDark ? '#FFFFFF' : '#000000'
              }
            ]}
            placeholder="Surah Name"
            placeholderTextColor={isDark ? '#888888' : '#666666'}
            value={formData.memorizationSurah}
            onChangeText={(text) => setFormData({
              ...formData,
              memorizationSurah: text
            })}
          />
          <View style={styles.row}>
            <TextInput
              style={[
                styles.input,
                styles.halfInput,
                { 
                  backgroundColor: isDark ? '#1A1B1E' : '#FFFFFF',
                  color: isDark ? '#FFFFFF' : '#000000'
                }
              ]}
              placeholder="From Ayah"
              placeholderTextColor={isDark ? '#888888' : '#666666'}
              keyboardType="numeric"
              value={formData.memorizationFrom}
              onChangeText={(text) => setFormData({
                ...formData,
                memorizationFrom: text
              })}
            />
            <TextInput
              style={[
                styles.input,
                styles.halfInput,
                { 
                  backgroundColor: isDark ? '#1A1B1E' : '#FFFFFF',
                  color: isDark ? '#FFFFFF' : '#000000'
                }
              ]}
              placeholder="To Ayah"
              placeholderTextColor={isDark ? '#888888' : '#666666'}
              keyboardType="numeric"
              value={formData.memorizationTo}
              onChangeText={(text) => setFormData({
                ...formData,
                memorizationTo: text
              })}
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={[
            styles.sectionTitle,
            { color: isDark ? '#4CAF50' : '#2E7D32' }
          ]}>
            Revision
          </Text>
          <TextInput
            style={[
              styles.input,
              { 
                backgroundColor: isDark ? '#1A1B1E' : '#FFFFFF',
                color: isDark ? '#FFFFFF' : '#000000'
              }
            ]}
            placeholder="Surah Name"
            placeholderTextColor={isDark ? '#888888' : '#666666'}
            value={formData.revisionSurah}
            onChangeText={(text) => setFormData({
              ...formData,
              revisionSurah: text
            })}
          />
          <View style={styles.row}>
            <TextInput
              style={[
                styles.input,
                styles.halfInput,
                { 
                  backgroundColor: isDark ? '#1A1B1E' : '#FFFFFF',
                  color: isDark ? '#FFFFFF' : '#000000'
                }
              ]}
              placeholder="From Ayah"
              placeholderTextColor={isDark ? '#888888' : '#666666'}
              keyboardType="numeric"
              value={formData.revisionFrom}
              onChangeText={(text) => setFormData({
                ...formData,
                revisionFrom: text
              })}
            />
            <TextInput
              style={[
                styles.input,
                styles.halfInput,
                { 
                  backgroundColor: isDark ? '#1A1B1E' : '#FFFFFF',
                  color: isDark ? '#FFFFFF' : '#000000'
                }
              ]}
              placeholder="To Ayah"
              placeholderTextColor={isDark ? '#888888' : '#666666'}
              keyboardType="numeric"
              value={formData.revisionTo}
              onChangeText={(text) => setFormData({
                ...formData,
                revisionTo: text
              })}
            />
          </View>
        </View>

        <TouchableOpacity
          style={styles.saveButton}
          onPress={handleSave}
        >
          <Text style={styles.saveButtonText}>
            Save Entry
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 60,
    marginBottom: 20,
  },
  backButton: {
    marginRight: 16,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Amiri-Bold',
  },
  form: {
    flex: 1,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Amiri-Bold',
    marginBottom: 12,
  },
  input: {
    height: 48,
    borderRadius: 8,
    paddingHorizontal: 16,
    marginBottom: 12,
    fontFamily: 'Amiri-Regular',
    fontSize: 16,
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  halfInput: {
    flex: 1,
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 24,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontFamily: 'Amiri-Bold',
  },
});