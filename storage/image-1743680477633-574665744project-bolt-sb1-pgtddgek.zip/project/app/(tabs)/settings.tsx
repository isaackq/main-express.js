import { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Switch,
  TouchableOpacity,
  useColorScheme,
  Alert,
} from 'react-native';
import * as Notifications from 'expo-notifications';

export default function SettingsScreen() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  useEffect(() => {
    checkNotificationPermissions();
  }, []);

  const checkNotificationPermissions = async () => {
    const { status } = await Notifications.getPermissionsAsync();
    setNotificationsEnabled(status === 'granted');
  };

  const toggleNotifications = async () => {
    if (notificationsEnabled) {
      await Notifications.cancelAllScheduledNotificationsAsync();
      setNotificationsEnabled(false);
    } else {
      const { status } = await Notifications.requestPermissionsAsync();
      
      if (status === 'granted') {
        await scheduleNotifications();
        setNotificationsEnabled(true);
      } else {
        Alert.alert(
          'Permission Required',
          'Please enable notifications in your device settings to receive reminders.'
        );
      }
    }
  };

  const scheduleNotifications = async () => {
    await Notifications.cancelAllScheduledNotificationsAsync();

    await Notifications.scheduleNotificationAsync({
      content: {
        title: "Time for Quran Study! 📖",
        body: "Don't forget to complete today's memorization and revision tasks.",
      },
      trigger: {
        hour: 9,
        minute: 0,
        repeats: true,
      },
    });
  };

  const exportData = () => {
    // TODO: Implement PDF/Image export
    Alert.alert(
      'Coming Soon',
      'Export functionality will be available in the next update!'
    );
  };

  return (
    <View style={[
      styles.container,
      { backgroundColor: isDark ? '#121212' : '#F5F5F5' }
    ]}>
      <View style={styles.header}>
        <Text style={[
          styles.title,
          { color: isDark ? '#FFFFFF' : '#000000' }
        ]}>
          Settings
        </Text>
      </View>

      <View style={[
        styles.card,
        { backgroundColor: isDark ? '#1A1B1E' : '#FFFFFF' }
      ]}>
        <View style={styles.setting}>
          <Text style={[
            styles.settingTitle,
            { color: isDark ? '#FFFFFF' : '#000000' }
          ]}>
            Daily Reminders
          </Text>
          <Switch
            value={notificationsEnabled}
            onValueChange={toggleNotifications}
            trackColor={{ false: '#767577', true: '#4CAF50' }}
            thumbColor={notificationsEnabled ? '#FFFFFF' : '#f4f3f4'}
          />
        </View>

        <TouchableOpacity
          style={styles.exportButton}
          onPress={exportData}
        >
          <Text style={styles.exportButtonText}>
            Export Schedule
          </Text>
        </TouchableOpacity>

        <Text style={[
          styles.version,
          { color: isDark ? '#888888' : '#666666' }
        ]}>
          Version 1.0.0
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    marginTop: 60,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Amiri-Bold',
  },
  card: {
    borderRadius: 16,
    padding: 24,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  setting: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  settingTitle: {
    fontSize: 18,
    fontFamily: 'Amiri-Regular',
  },
  exportButton: {
    backgroundColor: '#4CAF50',
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  exportButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontFamily: 'Amiri-Bold',
  },
  version: {
    textAlign: 'center',
    fontSize: 14,
    fontFamily: 'Amiri-Regular',
  },
});