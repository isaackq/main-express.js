import { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  useColorScheme,
  TouchableOpacity,
  Platform,
} from 'react-native';
import { useFonts, Amiri_400Regular, Amiri_700Bold } from '@expo-google-fonts/amiri';
import { Plus } from 'lucide-react-native';
import { router } from 'expo-router';
import * as SQLite from 'expo-sqlite';

interface ScheduleEntry {
  id: number;
  day: string;
  memorizationSurah: string;
  memorizationFrom: number;
  memorizationTo: number;
  revisionSurah: string;
  revisionFrom: number;
  revisionTo: number;
  status: 'Completed' | 'Not Completed';
}

const days = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
];

export default function ScheduleScreen() {
  const [schedule, setSchedule] = useState<ScheduleEntry[]>([]);
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  const [fontsLoaded] = useFonts({
    'Amiri-Regular': Amiri_400Regular,
    'Amiri-Bold': Amiri_700Bold,
  });

  useEffect(() => {
    if (Platform.OS === 'ios' || Platform.OS === 'android') {
      try {
        const db = SQLite.openDatabase('qurantrack.db');
        
        db.transaction(tx => {
          tx.executeSql(
            `CREATE TABLE IF NOT EXISTS schedule (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              day TEXT,
              memorizationSurah TEXT,
              memorizationFrom INTEGER,
              memorizationTo INTEGER,
              revisionSurah TEXT,
              revisionFrom INTEGER,
              revisionTo INTEGER,
              status TEXT
            )`,
            [],
            () => {
              loadSchedule(db);
            },
            (_, error) => {
              console.error('Error creating table:', error);
              return false;
            }
          );
        });
      } catch (error) {
        console.error('Error opening database:', error);
        setSchedule([]);
      }
    } else {
      setSchedule([]);
    }
  }, []);

  const loadSchedule = (db: SQLite.WebSQLDatabase) => {
    try {
      db.transaction(tx => {
        tx.executeSql(
          'SELECT * FROM schedule',
          [],
          (_, { rows: { _array } }) => setSchedule(_array),
          (_, error) => {
            console.error('Error loading schedule:', error);
            return false;
          }
        );
      });
    } catch (error) {
      console.error('Error in loadSchedule:', error);
      setSchedule([]);
    }
  };

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View style={[
      styles.container,
      { backgroundColor: isDark ? '#121212' : '#F5F5F5' }
    ]}>
      <View style={styles.header}>
        <Text style={[
          styles.title,
          { color: isDark ? '#FFFFFF' : '#000000' }
        ]}>
          Weekly Schedule
        </Text>
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => router.push('/add-entry')}
        >
          <Plus size={24} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scheduleContainer}>
        {days.map((day, index) => {
          const entry = schedule.find(s => s.day === day);
          
          return (
            <View
              key={day}
              style={[
                styles.dayCard,
                { backgroundColor: isDark ? '#1A1B1E' : '#FFFFFF' }
              ]}
            >
              <Text style={[
                styles.dayTitle,
                { color: isDark ? '#FFFFFF' : '#000000' }
              ]}>
                {day}
              </Text>
              
              {entry ? (
                <View style={styles.entryContent}>
                  <View style={styles.section}>
                    <Text style={[
                      styles.sectionTitle,
                      { color: isDark ? '#4CAF50' : '#2E7D32' }
                    ]}>
                      Memorization
                    </Text>
                    <Text style={[
                      styles.sectionText,
                      { color: isDark ? '#FFFFFF' : '#000000' }
                    ]}>
                      {entry.memorizationSurah} ({entry.memorizationFrom}-{entry.memorizationTo})
                    </Text>
                  </View>

                  <View style={styles.section}>
                    <Text style={[
                      styles.sectionTitle,
                      { color: isDark ? '#4CAF50' : '#2E7D32' }
                    ]}>
                      Revision
                    </Text>
                    <Text style={[
                      styles.sectionText,
                      { color: isDark ? '#FFFFFF' : '#000000' }
                    ]}>
                      {entry.revisionSurah} ({entry.revisionFrom}-{entry.revisionTo})
                    </Text>
                  </View>

                  <View style={[
                    styles.statusBadge,
                    {
                      backgroundColor: entry.status === 'Completed'
                        ? '#4CAF50'
                        : '#FFA000'
                    }
                  ]}>
                    <Text style={styles.statusText}>
                      {entry.status}
                    </Text>
                  </View>
                </View>
              ) : (
                <TouchableOpacity
                  style={styles.addEntryButton}
                  onPress={() => router.push({
                    pathname: '/add-entry',
                    params: { day }
                  })}
                >
                  <Text style={[
                    styles.addEntryText,
                    { color: isDark ? '#4CAF50' : '#2E7D32' }
                  ]}>
                    Add Entry
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    marginTop: 60,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Amiri-Bold',
  },
  addButton: {
    backgroundColor: '#4CAF50',
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scheduleContainer: {
    flex: 1,
  },
  dayCard: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  dayTitle: {
    fontSize: 20,
    fontFamily: 'Amiri-Bold',
    marginBottom: 12,
  },
  entryContent: {
    gap: 12,
  },
  section: {
    gap: 4,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: 'Amiri-Bold',
  },
  sectionText: {
    fontSize: 16,
    fontFamily: 'Amiri-Regular',
  },
  statusBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    marginTop: 8,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'Amiri-Regular',
  },
  addEntryButton: {
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  addEntryText: {
    fontSize: 16,
    fontFamily: 'Amiri-Regular',
  },
});