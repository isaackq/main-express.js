import { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  useColorScheme,
} from 'react-native';
import { Brain } from 'lucide-react-native';

export default function MemorizeScreen() {
  const [formData, setFormData] = useState({
    daysPerWeek: '',
    versesPerDay: '',
    goal: '',
  });

  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  const handleGenerate = () => {
    // TODO: Implement AI schedule generation
    console.log('Generating schedule with:', formData);
  };

  return (
    <View style={[
      styles.container,
      { backgroundColor: isDark ? '#121212' : '#F5F5F5' }
    ]}>
      <View style={styles.header}>
        <Text style={[
          styles.title,
          { color: isDark ? '#FFFFFF' : '#000000' }
        ]}>
          AI Assistant
        </Text>
      </View>

      <ScrollView style={styles.content}>
        <View style={[
          styles.card,
          { backgroundColor: isDark ? '#1A1B1E' : '#FFFFFF' }
        ]}>
          <Brain
            size={48}
            color={isDark ? '#4CAF50' : '#2E7D32'}
            style={styles.icon}
          />
          
          <Text style={[
            styles.description,
            { color: isDark ? '#FFFFFF' : '#000000' }
          ]}>
            Let me help you create a personalized Quran memorization schedule based on your goals and availability.
          </Text>

          <View style={styles.form}>
            <View style={styles.inputGroup}>
              <Text style={[
                styles.label,
                { color: isDark ? '#FFFFFF' : '#000000' }
              ]}>
                How many days per week can you memorize?
              </Text>
              <TextInput
                style={[
                  styles.input,
                  { 
                    backgroundColor: isDark ? '#2C2D30' : '#F5F5F5',
                    color: isDark ? '#FFFFFF' : '#000000'
                  }
                ]}
                keyboardType="numeric"
                placeholder="Enter number of days"
                placeholderTextColor={isDark ? '#888888' : '#666666'}
                value={formData.daysPerWeek}
                onChangeText={(text) => setFormData({
                  ...formData,
                  daysPerWeek: text
                })}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={[
                styles.label,
                { color: isDark ? '#FFFFFF' : '#000000' }
              ]}>
                How many verses can you memorize per day?
              </Text>
              <TextInput
                style={[
                  styles.input,
                  { 
                    backgroundColor: isDark ? '#2C2D30' : '#F5F5F5',
                    color: isDark ? '#FFFFFF' : '#000000'
                  }
                ]}
                keyboardType="numeric"
                placeholder="Enter number of verses"
                placeholderTextColor={isDark ? '#888888' : '#666666'}
                value={formData.versesPerDay}
                onChangeText={(text) => setFormData({
                  ...formData,
                  versesPerDay: text
                })}
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={[
                styles.label,
                { color: isDark ? '#FFFFFF' : '#000000' }
              ]}>
                What is your goal? (e.g., 1 Juz in 30 days)
              </Text>
              <TextInput
                style={[
                  styles.input,
                  { 
                    backgroundColor: isDark ? '#2C2D30' : '#F5F5F5',
                    color: isDark ? '#FFFFFF' : '#000000'
                  }
                ]}
                placeholder="Enter your goal"
                placeholderTextColor={isDark ? '#888888' : '#666666'}
                value={formData.goal}
                onChangeText={(text) => setFormData({
                  ...formData,
                  goal: text
                })}
              />
            </View>

            <TouchableOpacity
              style={styles.generateButton}
              onPress={handleGenerate}
            >
              <Text style={styles.generateButtonText}>
                Generate Schedule
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    marginTop: 60,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Amiri-Bold',
  },
  content: {
    flex: 1,
  },
  card: {
    borderRadius: 16,
    padding: 24,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  icon: {
    alignSelf: 'center',
    marginBottom: 16,
  },
  description: {
    fontSize: 16,
    fontFamily: 'Amiri-Regular',
    textAlign: 'center',
    marginBottom: 24,
  },
  form: {
    gap: 20,
  },
  inputGroup: {
    gap: 8,
  },
  label: {
    fontSize: 16,
    fontFamily: 'Amiri-Bold',
  },
  input: {
    height: 48,
    borderRadius: 8,
    paddingHorizontal: 16,
    fontFamily: 'Amiri-Regular',
    fontSize: 16,
  },
  generateButton: {
    backgroundColor: '#4CAF50',
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
  },
  generateButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontFamily: 'Amiri-Bold',
  },
});